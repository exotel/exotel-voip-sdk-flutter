package com.exotel.voice_sample;

import com.exotel.voice.ExotelVoiceClient;

public class ExotelVoiceClientWrapper {

    private ExotelVoiceClient exotelVoiceClient;



}
