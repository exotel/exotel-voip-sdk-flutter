package com.exotel.voice_sample;

/* Part of CallDetails used to populate the Recent Call Tab */
public enum CallType {

    INCOMING,

    OUTGOING,

    MISSED

}
