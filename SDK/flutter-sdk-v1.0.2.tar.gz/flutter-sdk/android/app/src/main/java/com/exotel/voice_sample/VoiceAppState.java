package com.exotel.voice_sample;

public enum VoiceAppState {


    STATUS_READY,

    STATUS_NOT_INITIALIZED,

    STATUS_INITIALIZATION_FAILURE,

    STATUS_INITIALIZATION_IN_PROGRESS,

}
