package com.exotel.voice_sample;

public interface VoiceAppStatusEvents {

    void onStatusChange();

    void onAuthFailure();

}
