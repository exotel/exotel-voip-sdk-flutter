package com.exotel.voice_sample;

public interface CallContextEvents {

    void onGetContextSuccess();

}

