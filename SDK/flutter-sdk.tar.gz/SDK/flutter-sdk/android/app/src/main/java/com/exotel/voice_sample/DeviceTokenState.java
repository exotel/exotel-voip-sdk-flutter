package com.exotel.voice_sample;

public enum DeviceTokenState {

    DEVICE_TOKEN_NOT_SENT,

    DEVICE_TOKEN_SEND_SUCCESS,

    DEVICE_TOKEN_SEND_FAILURE

}

