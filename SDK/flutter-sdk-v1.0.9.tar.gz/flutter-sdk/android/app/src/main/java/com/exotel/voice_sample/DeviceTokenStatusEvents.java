package com.exotel.voice_sample;

public interface DeviceTokenStatusEvents {


    void deviceTokenStatusChange();

}
