// import 'ExotelVoiceClient.dart';
//
// import 'ExotelSDKClient.dart';
//
// class ExotelVoiceClientFactory {
//   static ExotelVoiceClient _exotelVoiceClient = new ExotelSDKClient();
//   static ExotelVoiceClient getExotelVoiceClient() {
//     if(_exotelVoiceClient == null){
//       _exotelVoiceClient = new ExotelSDKClient();
//     }
//     return _exotelVoiceClient;
//   }
// }