# Changelog

All notable changes to this project will be documented in this file.

## [1.0.14] 29-09-2026
- [VST-2193](https://exotel.atlassian.net/browse/VST-2193): keep the microphone working when the app is in the background during a call. The foreground service adds the microphone type on dial/answer and drops it when the call ends; the service is also started at call time if it was not started earlier.
- [VST-2136](https://exotel.atlassian.net/browse/VST-2136): added forceReset(); initialize/reset/stop now always return a result, and errors carry the underlying exception.
- Bundled Exotel Voice Android SDK 1.0.73 (VST-2136, VST-2195).

## [1.0.13] 09-09-2025
- [VST-1087](https://exotel.atlassian.net/browse/VST-1087): fixed s3 log upload.

## [1.0.12] 18-06-2025
- [VST-1068](https://exotel.atlassian.net/browse/VST-1068): Fix the crash causing by Boot_Start broadcast listener for stating the foreground service

## [1.0.11] 18-06-2025
- [VST-1030](https://exotel.atlassian.net/browse/VST-1030): removed microphone service to fix crash

## [1.0.10] 11-12-2024
### Changed
* [VST-907](https://exotel.atlassian.net/browse/VST-907): Handle Permission Denial Callback

## [1.0.9] 28-11-2024
### Changed
* [VST-894](https://exotel.atlassian.net/browse/VST-894): Modify subscriber_token Handling, use JSON string using jsonEncode before being used and stored
